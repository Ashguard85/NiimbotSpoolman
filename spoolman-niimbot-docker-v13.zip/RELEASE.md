

## v13 – vereinfachte Oberfläche
- Schnellansicht: Spool auswählen → Vorlage wählen → drucken.
- Vorlagen als antippbare Kacheln.
- Detailfunktionen unter „Label anpassen“ gruppiert, ohne Funktionen zu entfernen.
- QR- und Druck-Expertenoptionen in aufklappbaren Bereichen.
- Feste Druckleiste mit B1-Status, Kopien und Druckbutton.
- Mobilansicht optimiert; nach Spool-Auswahl springt die Ansicht direkt zum Label.
- Text- und QR-Regler werden nur gezeigt, wenn sie für den gewählten Modus relevant sind.
# Release v10
- Eigenständiger Spoolman→NIIMBOT-Dienst
- Android-/Tablet-first UI
- dynamische Nutzung aller Spoolman-Spool-/Filament-/Vendor-/Extra-Felder
- Vorlagen mit Platzhaltern und Feldbrowser
- Formate 40×40, 50×30, 30×20, 50×50
- direkte B1-Ausgabe über Web Bluetooth
- Spoolman-URL, web+spoolman-Code oder Spool-ID als QR
- Android Web Share Target
- Local-/Server-Modus
- Docker-Spoolman-Proxy, SQLite Templates/History, Backup/Restore

## Dynamische Etiketten

- Beliebig viele Textzeilen statt fest drei Zeilen.
- Leere Spoolman-Felder blenden die betroffene Zeile automatisch aus.
- Automatische Schriftgröße und vertikale Verteilung anhand der tatsächlich sichtbaren Zeilen.
- Layoutwahl: Automatisch, QR links oder QR oben.
- Neue 50×30-Vorlage „Spoolman dynamisch“ im Stil QR links / Daten rechts.
- Alte v1-Vorlagen und v1-Backups bleiben importierbar.

- 50×30-Querformat: QR links nutzt jetzt nahezu die volle nutzbare Labelhöhe; Text rechts skaliert dynamisch in der Restbreite.

- Neue QR-Größe-Auswahl in der UI: ausgewogen, QR groß, QR sehr groß, automatisch.

- Neuer QR-Breiten-Slider in % sowie Text-Ausrichtung oben/mittig/unten.
- Automatische QR-Größe und Text-Ausrichtung berücksichtigen jetzt die tatsächliche Zeilenzahl.

- QR-Renderer korrigiert: der bisher intern fest reservierte 4-Modul-Rand ist jetzt einstellbar (0/1/2/4).
- 50×30 Seitenlayout nutzt nur noch 2 px äußeren QR-Abstand und kann die volle Labelhöhe besser ausnutzen.
- QR-ECC L/M/Q/H konfigurierbar; dynamische 50×30-Vorlage nutzt standardmäßig ECC L + 1 Modul Rand für größere Druckmodule.
- Optionaler QuickChart-QR-Renderer mit automatischem lokalem Fallback.
- Renderstatus zeigt jetzt QR-Feld- und tatsächliche Code-Pixelgröße.

- Textgröße pro Vorlage: Automatisch oder benutzerdefinierte Maximalgröße 8–30 px; bei Platzmangel wird sicher verkleinert.

- Textblock kann normal, 90° im Uhrzeigersinn oder 90° gegen Uhrzeigersinn gerendert werden.
- Optionaler automatischer Wortumbruch; manuelle Zeilenumbrüche bleiben erhalten.

- Druckfix: Canvas wird direkt an den NIIMBOT-Rasterpfad übergeben; kein `data:`-/Blob-Bildladen mehr vor dem BLE-Druck.
- B1-Transport wird konservativ auf paced + BUNDLE_MAX 180 gesetzt, sofern vom Treiber unterstützt.
- Eigene Vorlagen können jetzt über „Vorlage löschen“ entfernt werden; Standardvorlagen bleiben geschützt.
- Service-Worker-App-Shell auf v10-Assets korrigiert.

- iPhone-Layout korrigiert: keine feste Tablet-Mindestbreite/kein großer horizontaler Leerraum mehr.
- Ausgewählte Vorlage kann als Standard festgelegt werden; sie wird beim nächsten Start automatisch geladen.

- v13: individuelle Textgrößen pro Textzeile mit [S], [M], [L], [XL] oder exakten Pixelwerten wie [22]. Größenbuttons im Editor setzen die Markierung für die aktuelle Zeile.
